process.env.NODE_ENV = "test";

const { expect } = require("chai");
const chai = require("chai");
const chaiHttp = require("chai-http");
const endpoints = require("./endpoints.js");

chai.use(chaiHttp);

const description = "test description";

describe("Description", () => {
  // Before each test we empty the database
  beforeEach((done) => {
    chai
      .request(endpoints.clearDb)
      .get("/")
      .end((err, res) => {
        expect(res).to.have.status(200);
        done();
      });
  });

  describe("Description is stored on server", () => {
    it("By adding new product", (done) => {
      chai
        .request(endpoints.product)
        .post("/")
        .set("Accept", "application/json")
        .send({
          name: "Milk",
          description: description,
          price: 0,
          itemCount: 0,
          active: true,
        })
        .end((err, res) => {
          expect(res).to.have.status(200);
          expect(res.body).to.deep.include({ description: description });

          const id = res.body.id;

          chai
            .request(endpoints.product)
            .get("/" + id)
            .set("Accept", "application/json")
            .end((err, res) => {
              expect(res).to.have.status(200);
              expect(res.body).to.deep.include({ description: description });
              done();
            });
        });
    });

    it("By editing existing product", (done) => {
      // Create dummy product
      chai
        .request(endpoints.product)
        .post("/")
        .set("Accept", "application/json")
        .send({
          name: "Milk",
          description: description,
          price: 0,
          itemCount: 0,
          active: true,
        })
        .end((err, res) => {
          expect(res).to.have.status(200);

          const id = res.body.id;

          // Edit description
          chai
            .request(endpoints.product)
            .put("/" + id)
            .set("Accept", "application/json")
            .send({
              description: description,
            })
            .end((err, res) => {
              expect(res).to.have.status(200);
              expect(res.body).to.deep.include({ description: description });

              // Get product
              chai
                .request(endpoints.product)
                .get("/" + id)
                .set("Accept", "application/json")
                .end((err, res) => {
                  expect(res).to.have.status(200);
                  expect(res.body).to.deep.include({
                    description: description,
                  });
                  done();
                });
            });
        });
    });
  });
});
