module.exports = {
  clearDb: 'https://schqarecruitment.azurewebsites.net/v1/clearDb',
  products: 'https://schqarecruitment.azurewebsites.net/v1/products',
  product: 'https://schqarecruitment.azurewebsites.net/v1/product'
};